<?php
// Heading
$_['heading_title']    = 'A&ccedil;&otilde;es de Devolu&ccedil;&otilde;es';

// Text
$_['text_success']	   = 'A&ccedil;&atilde;o de Devolu&ccedil;&otilde;es modificada com sucesso!';

// Column
$_['column_name']      = 'A&ccedil;&atilde;o de Devolu&ccedil;&otilde;es';
$_['column_action']    = 'A&ccedil;&atilde;o';

// Entry
$_['entry_name']       = 'A&ccedil;&atilde;o de Devolu&ccedil;&otilde;es:';

// Error
$_['error_permission'] = 'Aten&ccedil;&atilde;o: Voc&ecirc; n&atilde;o possui permiss&atilde;o para modificar as a&ccedil;&otilde;es de devolu&ccedil;&otilde;es!';
$_['error_name']       = 'Aten&ccedil;&atilde;o: O campo <b>A&ccedil;&atilde;o de Devolu&ccedil;&otilde;es</b> deve ter entre 3 e 32 caracteres!';
$_['error_return']     = 'Aten&ccedil;&atilde;o: Esta a&ccedil;&atilde;o de devolu&ccedil;&otilde;es n&atilde;o pode ser exclu&iacute;da, pois est&aacute; vinculada a %s devolu&ccedil;&atilde;o(&ocirc;es)!';
?>