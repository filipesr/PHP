<?php
// Heading
$_['heading_title']    = 'Motivos de Devolu&ccedil;&otilde;es';

// Text
$_['text_success']	   = 'Motivo de Devolu&ccedil;&otilde;es modificado com sucesso!';

// Column
$_['column_name']      = 'Motivo de Devolu&ccedil;&otilde;es';
$_['column_action']    = 'A&ccedil;&atilde;o';

// Entry
$_['entry_name']       = 'Motivo de Devolu&ccedil;&otilde;es:';

// Error
$_['error_permission'] = 'Aten&ccedil;&atilde;o: Voc&ecirc; n&atilde;o possui permiss&atilde;o para modificar os motivos de devolu&ccedil;&otilde;es!';
$_['error_name']       = 'Aten&ccedil;&atilde;o: O campo <b>Motivo de Devolu&ccedil;&otilde;es</b> deve ter entre 3 e 32 caracteres!';
$_['error_return']     = 'Aten&ccedil;&atilde;o: Este motivo de devolu&ccedil;&otilde;es n&atilde;o pode ser exclu&iacute;do, pois est&aacute; vinculado a %s devolu&ccedil;&atilde;o(&ocirc;es)!';
?>