<?php
// header
$_['heading_title']	 = 'Administra&ccedil;&atilde;o';

// Text
$_['text_heading']	 = 'Administra&ccedil;&atilde;o';
$_['text_login']	 = 'Digite abaixo suas informa&ccedil;&otilde;es de acesso.';
$_['text_forgotten'] = 'Esqueceu sua senha?';

// Entry
$_['entry_username'] = 'Seu Usu&aacute;rio:';
$_['entry_password'] = 'Sua Senha:';

// Button
$_['button_login']	 = 'Acessar';

// Error
$_['error_login']	 = 'Usu&aacute;rio e/ou senha inv&aacute;lido(s).';
$_['error_token']	 = 'Token de sess&atilde;o inv&aacute;lido. Por favor, efetue o login novamente.';
?>
