<?php
// Text
$_['text_footer'] = 'Criado com <a href="http://www.opencart.com">OpenCart</a> &copy; 2009-' . date('Y') . ' Todos os direitos reservados.<br />Vers&atilde;o  %s';
?>