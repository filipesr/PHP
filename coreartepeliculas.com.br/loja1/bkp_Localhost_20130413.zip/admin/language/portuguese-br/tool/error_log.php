<?php
// Heading
$_['heading_title'] = 'Logs de Erros';

// Text
$_['text_success']  = 'Logs de erros apagados com sucesso!';
?>