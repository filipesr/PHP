<?php
// Heading
$_['heading_title']    = 'Retirada na Loja';

// Text 
$_['text_shipping']    = 'Formas de Envio';
$_['text_success']     = 'Módulo Retirada na Loja modificado com sucesso!';

// Entry
$_['entry_geo_zone']   = 'Regi&atilde;o Geogr&aacute;fica:';
$_['entry_status']     = 'Situa&ccedil;&atilde;o:';
$_['entry_sort_order'] = 'Ordem:';

// Error
$_['error_permission'] = 'Aten&ccedil;&atilde;o: Voc&ecirc; n&atilde;o possui permiss&atilde;o para modificar o módulo Retirada na Loja!';
?>