<?php
// Heading
$_['heading_title']    = 'Google Sitemap';

// Text 
$_['text_feed']        = 'Feed de Pel&iacute;culas';
$_['text_success']     = 'Módulo Google Sitemap modificado com sucesso!';

// Entry
$_['entry_status']     = 'Situa&ccedil;&atilde;o:';
$_['entry_data_feed']  = 'URL do Feed:';

// Error
$_['error_permission'] = 'Aten&ccedil;&atilde;o: Voc&ecirc; n&atilde;o possui permiss&atilde;o para modificar o módulo Google Sitemap!';
?>