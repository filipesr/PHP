<?php
// Heading
$_['heading_title']    = 'Cr&eacute;dito na Loja';

// Text
$_['text_total']       = 'Finaliza&ccedil;&atilde;o do Pedido';
$_['text_success']     = 'Módulo Cr&eacute;dito na Loja modificado com sucesso!';

// Entry
$_['entry_status']     = 'Situa&ccedil;&atilde;o:';
$_['entry_sort_order'] = 'Ordem:';

// Error
$_['error_permission'] = 'Aten&ccedil;&atilde;o: Voc&ecirc; n&atilde;o possui permiss&atilde;o para modificar o módulo Cr&eacute;dito na Loja!';
?>