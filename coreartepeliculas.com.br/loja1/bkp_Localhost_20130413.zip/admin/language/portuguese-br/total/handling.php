<?php
// Heading
$_['heading_title']    = 'Taxa de Manuseio';

// Text
$_['text_total']       = 'Finaliza&ccedil;&atilde;o do Pedido';
$_['text_success']     = 'Módulo Taxa de Manuseio modificada com sucesso!';

// Entry
$_['entry_total']      = 'Total do Pedido:';
$_['entry_fee']        = 'Taxa:';
$_['entry_tax_class']  = 'Grupo de Impostos:';
$_['entry_status']     = 'Situa&ccedil;&atilde;o:';
$_['entry_sort_order'] = 'Ordem:';

// Error
$_['error_permission'] = 'Aten&ccedil;&atilde;o: Voc&ecirc; n&atilde;o possui permiss&atilde;o para modificar o módulo Taxa de Manuseio!';
?>