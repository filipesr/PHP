<?php
// Heading
$_['heading_title']    = 'Simular Frete';

// Text
$_['text_total']       = 'Finaliza&ccedil;&atilde;o do Pedido';
$_['text_success']     = 'Módulo Frete modificado com sucesso!';

// Entry
$_['entry_estimator']  = 'Simular Frete:';
$_['entry_status']     = 'Situa&ccedil;&atilde;o:';
$_['entry_sort_order'] = 'Ordem:';

// Error
$_['error_permission'] = 'Aten&ccedil;&atilde;o: Voc&ecirc; n&atilde;o possui permiss&atilde;o para modificar o módulo Frete!';
?>