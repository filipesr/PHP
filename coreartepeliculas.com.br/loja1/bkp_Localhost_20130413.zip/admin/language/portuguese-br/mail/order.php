<?php
// Text
$_['text_subject']		= '%s - Pedido %s Atualizado';
$_['text_order']		= 'Pedido Nº:';
$_['text_date_added']	= 'Data do Pedido:';
$_['text_order_status']	= 'Seu pedido foi atualizado para a seguinte situa&ccedil;&atilde;o:';
$_['text_comment']		= 'Os coment&aacute;rios para o seu pedido s&atilde;o:';
$_['text_link']			= 'Para acompanhar o andamento do seu pedido, clique no link abaixo:';
$_['text_footer']		= 'Caso tenha alguma dúvida responda este e-mail.';
?>