<?php
// Text
$_['text_subject']  = '%s - Solicita&ccedil;&atilde;o de redefini&ccedil;&atilde;o de senha';
$_['text_greeting'] = 'Foi solicitada a redefini&ccedil;&atilde;o de senha para administra&ccedil;&atilde;o da loja %s.';
$_['text_change']   = 'Para recadastrar sua senha, clique no link abaixo:';
$_['text_ip']       = 'O IP utilizado para fazer esta solicita&ccedil;&atilde;o foi: %s';
?>