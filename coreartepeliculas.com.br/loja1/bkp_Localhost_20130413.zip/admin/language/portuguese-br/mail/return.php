<?php
// Text
$_['text_subject']       = '%s - Solicita&ccedil;&atilde;o de Devolu&ccedil;&atilde;o Atualizada %s';
$_['text_return_id']     = 'Devolu&ccedil;&atilde;o Nº:';
$_['text_date_added']    = 'Data da Devolu&ccedil;&atilde;o:';
$_['text_return_status'] = 'Sua solicita&ccedil;&atilde;o de devolu&ccedil;&atilde;o foi atualizada para a seguinte situa&ccedil;&atilde;o:';
$_['text_comment']       = 'Os coment&aacute;rios para a sua solicita&ccedil;&atilde;o de devolu&ccedil;&atilde;o s&atilde;o:';
$_['text_footer']        = 'Caso tenha alguma dúvida responda este e-mail.';
?>