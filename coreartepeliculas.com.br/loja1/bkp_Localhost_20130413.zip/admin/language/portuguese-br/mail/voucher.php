<?php
// Text
$_['text_subject']  = 'Voc&ecirc; recebeu um vale presentes de %s';
$_['text_greeting'] = 'Parab&eacute;ns! Voc&ecirc; acaba de receber um vale presentes de %s';
$_['text_from']     = 'Quem lhe enviou este vale presentes foi %s';
$_['text_message']  = 'Com a seguinte mensagem:';
$_['text_redeem']   = 'Para utilizar este vale presentes anote o código: <b>%s</b>.<br />Agora clique no link abaixo e fa&ccedil;a a compra das pel&iacute;culas que voc&ecirc; desejar!<br /><b>Importante:</b> Se o valor total do seu pedido ultrapassar o valor do vale presentes que voc&ecirc; recebeu, voc&ecirc; poder&aacute; pagar a diferen&ccedil;a do valor excedido diretamente na loja.<br />Para utilizar o seu vale presentes, voc&ecirc; deve inserir o código dele na p&aacute;gina do seu carrinho de compras antes mesmo de finalizar o pedido.';
$_['text_footer']   = 'Caso tenha alguma dúvida responda este e-mail.';
?>