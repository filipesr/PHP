<?php
// Text
$_['text_approve_subject']      = '%s - Sua conta de afiliado foi ativada!';
$_['text_approve_welcome']      = 'Obrigado por se cadastar na loja %s!';
$_['text_approve_login']        = 'Sua conta j&aacute; foi ativada e voc&ecirc; j&aacute; pode acessar o sua conta do Programa de Afiliados utilizando seu endere&ccedil;o de e-mail e senha visitando nossa loja ou no seguinte endere&ccedil;o:';
$_['text_approve_services']     = 'Ao acessar sua conta, voc&ecirc; ser&aacute; capaz de gerar links das pel&iacute;culas para divulgar em seu site ou blog, controlar pagamentos de comiss&otilde;es e editar as informa&ccedil;&otilde;es de sua conta.';
$_['text_approve_thanks']       = 'Obrigado,';
$_['text_transaction_subject']  = '%s - Comiss&atilde;o';
$_['text_transaction_received'] = 'Voc&ecirc; recebeu %s de comiss&atilde;o!';
$_['text_transaction_total']    = 'O total de sua comiss&atilde;o &eacute;: %s.';
?>