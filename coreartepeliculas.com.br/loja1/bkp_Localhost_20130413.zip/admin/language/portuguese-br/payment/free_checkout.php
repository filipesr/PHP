<?php
// Heading
$_['heading_title']		 = 'Pagamento Gr&aacute;tis';

// Text
$_['text_payment']		 = 'Formas de Pagamento';
$_['text_success']		 = 'Módulo Pagamento Gr&aacute;tis modificado com sucesso!';

// Entry
$_['entry_order_status'] = 'Situa&ccedil;&atilde;o do Pedido:';
$_['entry_status']		 = 'Situa&ccedil;&atilde;o:';
$_['entry_sort_order']	 = 'Ordem:';

// Error
$_['error_permission']	 = 'Aten&ccedil;&atilde;o: Voc&ecirc; n&atilde;o possui permiss&atilde;o para modificar o módulo Pagamento Gr&aacute;tis!';
?>