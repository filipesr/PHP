<?php
// Heading
$_['heading_title']   = 'Permiss&atilde;o Negada!'; 

// Text
$_['text_permission'] = 'Voc&ecirc; n&atilde;o tem premiss&atilde;o para acessar esta p&aacute;gina, entre em contato com a administra&ccedil;&atilde;o da loja.';
?>