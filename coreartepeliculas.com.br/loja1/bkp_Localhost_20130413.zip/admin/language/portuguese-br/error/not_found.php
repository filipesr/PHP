<?php
// Heading
$_['heading_title']  = 'P&aacute;gina n&atilde;o Encontrada!';

// Text
$_['text_not_found'] = 'A p&aacute;gina que voc&ecirc; tentou acessar n&atilde;o foi encontrada! Por favor, entre em contato conosco caso o problema n&atilde;o for resolvido.';
?>