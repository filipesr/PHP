<?php
// Heading
$_['heading_title']	   = 'Módulos';

// Text
$_['text_install']	   = 'Instalar';
$_['text_uninstall']   = 'Desinstalar';

// Column
$_['column_name']	   = 'Módulo';
$_['column_action']	   = 'A&ccedil;&atilde;o';

// Error
$_['error_permission'] = 'Aten&ccedil;&atilde;o: Voc&ecirc; n&atilde;o tem permiss&atilde;o para modificar os módulos!';
?>