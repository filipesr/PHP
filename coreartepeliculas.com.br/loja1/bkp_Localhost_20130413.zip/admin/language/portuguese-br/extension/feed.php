<?php
// Heading
$_['heading_title']	   = 'Feed de Pel&iacute;culas';

// Text
$_['text_install']	   = 'Instalar';
$_['text_uninstall']   = 'Desinstalar';

// Column
$_['column_name']	   = 'Feed';
$_['column_status']	   = 'Situa&ccedil;&atilde;o';
$_['column_action']	   = 'A&ccedil;&atilde;o';

// Error
$_['error_permission'] = 'Aten&ccedil;&atilde;o: Voc&ecirc; n&atilde;o tem permiss&atilde;o para modificar os feeds de pel&iacute;culas!';
?>