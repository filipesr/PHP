<?php
// Heading
$_['heading_title']		= 'Formas de Envio';

// Text
$_['text_install']		= 'Instalar';
$_['text_uninstall']	= 'Desinstalar';

// Column
$_['column_name']		= 'Forma de Envio';
$_['column_status']		= 'Situa&ccedil;&atilde;o';
$_['column_sort_order']	= 'Ordem';
$_['column_action']		= 'A&ccedil;&atilde;o';

// Error
$_['error_permission']  = 'Aten&ccedil;&atilde;o: Voc&ecirc; n&atilde;o tem permiss&atilde;o para modificar as formas de envio!';
?>