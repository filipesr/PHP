<?php
// Heading
$_['heading_title']  = 'Relatório de Pel&iacute;culas Visualizadas';

// Text
$_['text_success']   = 'Voc&ecirc; zerou o relatório de visualiza&ccedil;&atilde;o de pel&iacute;culas!';

// Column
$_['column_name']    = 'Pel&iacute;cula';
$_['column_model']   = 'Modelo';
$_['column_viewed']  = 'Visualiza&ccedil;&otilde;es';
$_['column_percent'] = 'Percentual';
?>