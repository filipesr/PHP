<?php
// Heading
$_['heading_title']         = 'Relatório de Pedidos por Cliente';

// Text
$_['text_all_status']       = 'Todas as Situa&ccedil;&otilde;es';

// Column
$_['column_customer']       = 'Cliente';
$_['column_email']          = 'E-mail';
$_['column_customer_group'] = 'Grupo de Clientes';
$_['column_status']         = 'Situa&ccedil;&atilde;o';
$_['column_orders']         = 'Pedidos';
$_['column_products']       = 'Pel&iacute;culas';
$_['column_total']          = 'Total';
$_['column_action']         = 'A&ccedil;&atilde;o';

// Entry
$_['entry_date_start']      = 'In&iacute;cio:';
$_['entry_date_end']        = 'Fim:';
$_['entry_status']          = 'Situa&ccedil;&atilde;o:';
?>