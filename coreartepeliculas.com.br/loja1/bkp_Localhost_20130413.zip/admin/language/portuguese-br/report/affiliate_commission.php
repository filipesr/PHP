<?php
// Heading
$_['heading_title']     = 'Relatório de Comiss&otilde;es por Afiliado';

// Column
$_['column_affiliate']  = 'Afiliado';
$_['column_email']      = 'E-mail';
$_['column_status']     = 'Situa&ccedil;&atilde;o';
$_['column_commission'] = 'Comiss&atilde;o';
$_['column_orders']     = 'Pedidos';
$_['column_total']      = 'Total';
$_['column_action']     = 'A&ccedil;&atilde;o';

// Entry
$_['entry_date_start']  = 'In&iacute;cio:';
$_['entry_date_end']    = 'Fim:';
?>