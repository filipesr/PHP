<?php
// Heading
$_['heading_title']     = 'Relatório de Pel&iacute;culas Compradas';

// Text
$_['text_all_status']   = 'Todas as Situa&ccedil;&otilde;es';

// Column
$_['column_date_start'] = 'Data Inicial';
$_['column_date_end']   = 'Data Final';
$_['column_name']       = 'Pel&iacute;cula';
$_['column_model']      = 'Modelo';
$_['column_quantity']   = 'Quantidade';
$_['column_total']      = 'Total';

// Entry
$_['entry_date_start']  = 'In&iacute;cio:';
$_['entry_date_end']    = 'Fim:';
$_['entry_status']      = 'Situa&ccedil;&atilde;o:';
?>