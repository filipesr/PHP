// TR lang variables

tinyMCE.addToLang('',{
searchreplace_search_desc : 'Ara',
searchreplace_searchnext_desc : 'Tekrar ara',
searchreplace_replace_desc : 'Bul/De�i�tir',
searchreplace_notfound : 'Arama tamamland�. Arad���n�z s�zc�k bulunamad�.',
searchreplace_search_title : 'Ara',
searchreplace_replace_title : 'Bul/De�i�tir',
searchreplace_allreplaced : 'T�m bulunan s�zc�kler de�i�tirildi.',
searchreplace_findwhat : 'Ara',
searchreplace_replacewith : 'ile de�i�tir',
searchreplace_direction : 'Arama y�n�',
searchreplace_up : 'Yukar�',
searchreplace_down : 'A�a��',
searchreplace_case : 'B�y�k/k���k harf duyarl�',
searchreplace_findnext : 'Ara&nbsp;�leri',
searchreplace_replace : 'De�i�tir',
searchreplace_replaceall : 'Hepsini&nbsp;de�i�tir',
searchreplace_cancel : '�ptal'
});
