// TR lang variables

tinyMCE.addToLang('',{
fullscreen_title : 'Tam ekran modu',
fullscreen_desc : 'Tam ekran moduna ge�'
});
