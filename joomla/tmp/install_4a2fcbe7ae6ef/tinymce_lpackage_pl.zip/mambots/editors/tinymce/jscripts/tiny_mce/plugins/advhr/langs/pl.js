// PL lang variables
// fixed by Wooya
// http://www.mfusion.prv.pl
// fixed by lemiel 14.11.2005

tinyMCE.addToLang('',{
insert_advhr_desc : 'Wstaw/Edytuj poziomą linię',
insert_advhr_width : 'Szerokość',
insert_advhr_size : 'Wysokość',
insert_advhr_noshade : 'Brak cienia'
});
