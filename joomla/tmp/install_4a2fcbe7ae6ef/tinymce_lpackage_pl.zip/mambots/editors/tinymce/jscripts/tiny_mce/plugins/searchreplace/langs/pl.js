// PL lang variables
// fixed by Wooya
// http://www.mfusion.prv.pl

tinyMCE.addToLang('',{
searchreplace_search_desc : 'ZnajdĽ',
searchreplace_searchnext_desc : 'ZnajdĽ ponownie',
searchreplace_replace_desc : 'ZnajdĽ/Zastąp',
searchreplace_notfound : 'Ukończono wyszukiwanie. Poszukiwana fraza nie została odnaleziona.',
searchreplace_search_title : 'ZnajdĽ',
searchreplace_replace_title : 'ZnajdĽ/Zastąp',
searchreplace_allreplaced : 'Wszystkie wystąpienia poszukiwanej frazy zostały zastąpione. ',
searchreplace_findwhat : 'ZnajdĽ',
searchreplace_replacewith : 'Zastąp',
searchreplace_direction : 'Kierunek',
searchreplace_up : 'Do góry',
searchreplace_down : 'Do dołu',
searchreplace_case : 'Wielkość liter',
searchreplace_findnext : 'ZnajdĽ&nbsp;następny',
searchreplace_replace : 'Zastąp',
searchreplace_replaceall : 'Zastąp&nbsp;wszystkie',
searchreplace_cancel : 'WyjdĽ'
});