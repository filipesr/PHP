// PL lang variables
// fixed by Wooya
// http://www.mfusion.prv.pl

tinyMCE.addToLang('',{
directionality_ltr_desc : 'Kierunek od lewej do prawej',
directionality_rtl_desc : 'Kierunek od prawej do lewej'
});
