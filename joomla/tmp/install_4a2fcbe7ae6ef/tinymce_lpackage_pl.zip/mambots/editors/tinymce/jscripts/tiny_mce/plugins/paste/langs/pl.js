// PL lang variables
// fixed by Wooya
// http://www.mfusion.prv.pl

tinyMCE.addToLang('',{
paste_text_desc : 'Wklej jako czysty tekst',
paste_text_title : 'Użyj CTRL+V na klawiaturze, aby wkleić tekst do okna.',
paste_text_linebreaks : 'Zachowaj łamanie linii',
paste_word_desc : 'Wklej z Worda',
paste_word_title : 'Użyj CTRL+V na klawiaturze, aby wkleić tekst do okna.',
selectall_desc : 'Zaznacz wszystko'
});