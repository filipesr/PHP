// DE lang variables

tinyMCE.addToLang('advimage',{
tab_general : 'Allgemein',
tab_appearance : 'Erscheinungsbild',
tab_advanced : 'Erweitert',
general : 'Allgemein',
title : 'Titel',
preview : 'Vorschau',
constrain_proportions : 'Verh&auml;ltnis beibehalten',
langdir : 'Textfluss',
langcode : 'Sprach-Code',
long_desc : 'Link zur ausf&uuml;hrlichen Beschreibung',
style : 'CSS-Stil',
classes : 'CSS-Klassen',
ltr : 'Von links nach rechts',
rtl : 'Von rechts nach links',
id : 'ID',
image_map : 'Image Map (Bild mit sensitiven Bereichen)',
swap_image : 'Bild austauschen',
alt_image : 'Alternatives Bild',
mouseover : 'f&uuml;r Mouse-Over',
mouseout : 'f&uuml;r Mouse-Out',
misc : 'Verschiedenes',
example_img : 'Erscheinungsbild&nbsp;Vorschau&nbsp;Bild',
missing_alt : 'Sind Sie sicher fortzufahren, ohne eine Bild-Beschreibung einzugeben? Ohne die Bild-Beschreibung k&ouml;nnen einige Besucher mit einer Behinderung, Besucher die nur einen Text-Browser benutzen oder die das Anzeigen von Bilder im Internet deaktiviert haben, Ihre Bilder nicht richtig sehen.'
});
