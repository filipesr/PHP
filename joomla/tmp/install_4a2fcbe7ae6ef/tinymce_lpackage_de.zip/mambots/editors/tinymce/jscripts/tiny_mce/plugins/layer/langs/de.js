// DE lang variables

tinyMCE.addToLang('layer',{
insertlayer_desc : 'Neue Ebene einf&uuml;gen',
forward_desc : 'Vorw&auml;rts schalten',
backward_desc : 'R&uuml;ckw&auml;rts schalten',
absolute_desc : 'Absolute Position schalten',
content : 'Neue Ebene...'
});
