// FR lang variables
// Modified by Motte, last updated 2006-03-23

tinyMCE.addToLang('advimage',{
tab_general : 'G&eacute;n&eacute;rale',
tab_appearance : 'Apparence',
tab_advanced : 'Avanc&eacute;',
general : 'G&eacute;n&eacute;rale',
title : 'Titre',
preview : 'Pr&eacute;visualisation',
constrain_proportions : 'Conserver les proportions',
langdir : 'Sens d\'&eacute;criture',
langcode : 'Code de langue du libell&eacute;',
long_desc : 'Description du lien',
style : 'Style',
classes : 'Classes',
ltr : 'De gauche &agrave; droite',
rtl : 'De droite &agrave; gauche',
id : 'Id',
image_map : 'Image map',
swap_image : 'Image d\'&eacute;change',
alt_image : 'Image alternative',
mouseover : 'Quand le pointeur est au dessus',
mouseout : 'Quand le pointeur est en dehors',
misc : 'Divers',
example_img : 'Apparence&nbsp;pr&eacute;visualisation&nbsp;image',
missing_alt : 'Etes vous sur de vouloir continuer sans inclure une description de l\'image. Cette description est utile pour les utilisateurs ne pouvant pas afficher les images ou les ayant d&eacute;sactiv&eacute;es.'
});