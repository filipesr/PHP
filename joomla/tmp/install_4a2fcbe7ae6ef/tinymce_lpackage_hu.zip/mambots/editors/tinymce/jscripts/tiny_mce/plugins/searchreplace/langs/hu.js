// HU lang variables

tinyMCE.addToLang('',{
searchreplace_search_desc : 'Keres�s',
searchreplace_searchnext_desc : '�jra keres�s',
searchreplace_replace_desc : 'Keres/Cser�l',
searchreplace_notfound : 'A keres�s elk�sz�lt. A keres�si sz�veg nem tal�lhat�.',
searchreplace_search_title : 'Keres',
searchreplace_replace_title : 'Keres/Cser�l',
searchreplace_allreplaced : 'A keres�s�i sz�veg minden el�fordul�sa cser�lve lett.',
searchreplace_findwhat : 'Mit keres',
searchreplace_replacewith : 'Mire cser�l',
searchreplace_direction : 'Hat�k�r',
searchreplace_up : 'Fel',
searchreplace_down : 'Le',
searchreplace_case : 'Teljes sz�',
searchreplace_findnext : 'K�vetkez�t&nbsp;keres',
searchreplace_replace : 'Cser�l',
searchreplace_replaceall : 'Mindent&nbsp;cser�l',
searchreplace_cancel : 'M�gse'
});
