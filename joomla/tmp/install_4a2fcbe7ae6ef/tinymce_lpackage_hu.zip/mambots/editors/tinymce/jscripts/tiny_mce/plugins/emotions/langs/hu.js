// HU lang variables

tinyMCE.addToLang('emotions',{
title : 'Hangulatjel besz�r�sa',
desc : 'Hangulatjelek',
cool : 'Kir�ly',
cry : 'S�r�s',
embarassed : 'Zavart',
foot_in_mouth : 'Foot in mouth',
frown : 'Homlokr�ncol�s',
innocent : '�rtatlan',
kiss : 'Cs�k',
laughing : 'Nevet�s',
money_mouth : 'P�nz�hes',
sealed : 'Eln�mult',
smile : 'Mosolyg�s',
surprised : 'Meglepett',
tongue_out : 'Tongue out',
undecided : 'Hat�rozatlan',
wink : 'Kacsint�s',
yell : 'Sikolt�s'
});
