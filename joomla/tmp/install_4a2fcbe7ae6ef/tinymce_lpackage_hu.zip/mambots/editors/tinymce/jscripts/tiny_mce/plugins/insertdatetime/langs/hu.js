// HU lang variables

tinyMCE.addToLang('',{
insertdate_def_fmt : '%Y-%m-%d',
inserttime_def_fmt : '%H:%M:%S',
insertdate_desc : 'D�tum besz�r�sa',
inserttime_desc : 'Id� besz�r�sa',
inserttime_months_long : new Array("Janu�r", "Febru�r", "M�rcius", "�prilis", "M�jus", "J�nius", "J�lius", "Augusztus", "Szeptember", "Okt�ber", "November", "December"),
inserttime_months_short : new Array("Jan", "Feb", "M�r", "�pr", "M�j", "J�n", "J�l", "Aug", "Sze", "Okt", "Nov", "Dec"),
inserttime_day_long : new Array("Vas�rnap", "H�tf�", "Kedd", "Szerda", "Cs�t�rt�k", "P�ntek", "Szombat", "Vas�rnap"),
inserttime_day_short : new Array("Vas", "H�", "Ke", "Sze", "Cs�", "P�n", "Szo", "Vas")
});
